export const ResumeParserAlgorithmArticle = () => {
  return <></>;
};
